#!/bin/bash

FILENAME=/home/vagrant/file.pcap

sudo rm -f $FILENAME && echo "File pcap cancellato"